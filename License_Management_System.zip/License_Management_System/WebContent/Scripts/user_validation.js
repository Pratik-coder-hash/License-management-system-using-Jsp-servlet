var submit = document.getElementById("reg");
if(submit)
    {
        submit.addEventListener("SUBMIT", validation,false); 
        function validation()
        {
	         var  valid = true;
            var username = document.getElementById("USERNAME").value;
            var pass = document.getElementById("PASSWORD").value;
            var fname = document.getElementById("FNAME").value;
            var mname = document.getElementById("MNAME").value;
            var lname = document.getElementById("LNAME").value;
            var age = document.getElementById("AGE").value;
            var dob = document.getElementById("DOB").value;
            var phone = document.getElementById("PHONE").value;
            var aadhar = document.getElementById("AADHAR").value;
            var pan = document.getElementById("{PANCARD").value;
            var qualification = document.getElementById("QUALIFICATION").value;
            var address = document.getElementById("ADDRESS").value;
            var city = document.getElementById("CITY").value;
            var state = document.getElementById("STATE").value;
            var country = document.getElementById("COUNTRY").value;
            var online = document.getElementById("ONLINE");
            var cash = document.getElementById("CASH");
            var male = document.getElementById("MALE");
            var female = document.getElementById("FEMALE");
            var other = document.getElementById("OTHER");
            
            
            
            var reg_username = new RegExp("[a-zA-Z0-9]+@[a-zA-Z]+[.][a-zA-Z]{2,3}");
            var reg_pass = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
            var reg_phone = new RegExp("[0-9]{10}");
            var reg_aadhar = new RegExp("[0-9]{10}");
            var reg_pan = new RegExp("[0-9]{10}");
           
            if(username == "" || !reg_username.test(username))
            {
				valid = false;
                alert("Username is not valid");
                document.getElementById("username").focus();
                return;
				
            }
			return valid;

            if(username.length < 6 && username.length > 20 )
            {
                alert("Username length must be in between 6 to 20 chars");
                document.getElementById("username").focus();
                return;
            }

			return valid;

    
            if(pass == "" || !reg_pass.test(pass))
            {
                    alert("Password is not valid");
                    document.getElementById("pass").focus();
                    return;
 					valid= "false";
            }
			return valid;

            
            if(fname == "" || mname == "" || lname == "" || dob == "" || address == "" || qualification == "")
            {
					valid = false;
            		alert("Please Enter Your Details");
            }

            return valid;

            if(phone == "" || !reg_phone.test(phone))
                {
					valid = false;
                    alert("<Mobile Number is not valid");
                    document.getElementById("phone").focus();
                    return;
                }
            return valid;


            if(phone.length < 10)
                {
					valid = false;
                    alert("Mobile no must be of 10 digits.")
                }
            return valid;


            if(age = "" && age.length < 18)
            {
				valid = false;
                alert("Your Age is not valid For Removal Of lIcense")
            }
			return valid;
            


            if(aadhar == "" || !reg_aadhar.test(aadhar))
                {
					valid = false;
                    alert("Aadhar Number is not valid");
                    document.getElementById("aadhar").focus();
                    return;
                }
			return valid;
            

            if(aadhar.length < 12)
                {
					valid = false;
                    alert("Aadhar Number must be of 12 digits.")
                }
            
			return valid;
			

            if(pan == "" || !reg_pan.test(pan))
                {
					valid = false;
                    alert("Pan_Card  is not valid");
                    document.getElementById("pan").focus();
                    return;
                }
            return valid;


            if(pan.length < 10)
                {
					valid = false;
                    alert("Pan_Card Number must be of 10 digits.")
                }
            return valid;

            
            if (online.checked == true){
            	valid = false;
            	alert("The payment type selected is:  " + online.value);
				}
            	
            	else if(cash.checked == true)

            		alert ("The payment type selected is:  " + cash.value);
            	
            	else
				
            		alert("Payment type is not selected");
				
            return valid;
            		
            
            if (male.checked == true){
            	valid = false;
            	alert("The Gender selected is:  " + male.value);
            	}
            	else if(female.checked == true)
            		alert ("The GENDER selected is:  " + female.value);
            	
            	else if(other.checked == true)
            		alert ("The GENDER selected is:  " + other.value);
            	
            	else
            		alert("Gender  is not selected"); 
			valid = false;
			

			 if ( city.selectedIndex == 0 )
   			 {
				 valid = false
       			 alert ( "Please select your City Please" );
       			 valid = false;
    		 }
			return valid;

		
			
			 if ( state.selectedIndex == 0 )
   			 {
				 valid = false;
       			 alert ( "Please select your State Please" );
       			 valid = false;
    		 }
			return valid;
			
			
			 if ( counrty.selectedIndex == 0 )
   			 {
				 valid = false;
       			 alert ( "Please select your State Please" );
       			 valid = false;
    		 }
			return valid;
			
			
            if(username != ""  &&  pass != ""  &&  fname !=""  &&  mname !=""  &&  lname !=""  &&  dob !=""  &&  phone !=""  &&  aadhar !=""  &&  pan !=""  &&  address !=""  &&  city !=""  &&  state !=""  &&  country !=""  &&  payment !=""  &&  qualification != ""  &&  gender != ""  &&  age != "" )
            {
                alert("Signed up successfully");
            }
  		 
					
        }
        
    }