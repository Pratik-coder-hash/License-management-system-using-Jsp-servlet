/**
 * http://usejsdoc.org/
 */


var submit = document.getElementById("licen");
if(submit)
    {
        submit.addEventListener("SUBMIT", validation, false); 
        function validation()
        {
			var valid = true;
            var app_id = document.getElementById("app_id").value;
            var learn_no = document.getElementById("learn_no").value;
            var exp_date = document.getElementById("exp_date").value;


			  if(app_id == "" || learn_no == "" || exp_date == "")
            {
					valid = false;
            		alert("Please Enter Your all License Details");
            }
			return valid;
            
          

			if(app_id != ""  &&  learn_no != ""  &&  exp_date !="")
			{
				alert("Thank You, Details Saved successfully");
			}
		}
}
