var submit = document.getElementById("SUBMIT");
if(submit)
    {
        submit.addEventListener("click", validation); 
        function validation()
        {
            var username = document.getElementById("username").value;
            var pass = document.getElementById("password").value;
            
            
            if(username != "" && pass != "" )
            {
                alert("Signed up successfully");
            }
        }
        
    }


