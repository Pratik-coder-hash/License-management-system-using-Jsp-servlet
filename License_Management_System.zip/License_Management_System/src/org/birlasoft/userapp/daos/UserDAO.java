package org.birlasoft.userapp.daos;

import org.birlasoft.userapp.pojo.Userinfo;

public interface UserDAO {

	public Userinfo authenticate(String Username,String Password) throws Exception;
	
	public boolean register(Userinfo userinfo) throws Exception;
	
	public boolean changePassword(String Username,String newPassword) throws Exception;
}
