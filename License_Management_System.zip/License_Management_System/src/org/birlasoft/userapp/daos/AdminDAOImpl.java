package org.birlasoft.userapp.daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.birlasoft.userapp.pojo.Admininfo;
import org.birlasoft.userapp.utils.ConnectionUtils;


public  class AdminDAOImpl implements AdminDAO {
	

	private PreparedStatement pst1,pst2,pst3;
	private Connection connection;	
	
	private static AdminDAO dao = null;
	
	public AdminDAOImpl() throws Exception {
		
		this.connection = ConnectionUtils.getConnection();
		
		this.pst1 = this.connection.prepareStatement("select * from admin_info where Username = ? and Password = ?");
		this.pst3 = this.connection.prepareStatement("update admin_info set Password = ? where Username = ?");		
	}
		
	
	@Override
	public Admininfo authenticate(String Username, String Password) throws Exception {		
		
		this.pst1.setString(1, Username);
		this.pst1.setString(2, Password);
		
		ResultSet res = this.pst1.executeQuery();
		
		if(res.next())
		{
			Admininfo u = new Admininfo(res.getString(1), res.getString(2) );
			return u;
		}		
		
		return null;
	}

	
	
	@Override
	public boolean changePassword(String Username, String newPassword) throws Exception {
		
		this.pst3.setString(1, newPassword);
		this.pst3.setString(2, Username);
		
		int status = this.pst3.executeUpdate();
		
		if(status > 0)
			return true;		
		
		return false;
	}
	
	public static AdminDAO getInstance() throws Exception
	{
		if(dao == null)
			dao = new AdminDAOImpl();
		
		return dao;
	}


	

}

	