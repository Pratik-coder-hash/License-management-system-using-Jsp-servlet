package org.birlasoft.userapp.daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.birlasoft.userapp.pojo.License_details;
import org.birlasoft.userapp.pojo.Userinfo;
import org.birlasoft.userapp.utils.ConnectionUtils;


public class LicenseDAOImpl implements LicenseDAO {
	
	private PreparedStatement pst1;
	private Connection connection;	
	
	private static LicenseDAO dao = null;
	
	public LicenseDAOImpl() throws Exception {
		
		this.connection = ConnectionUtils.getConnection();
		
		
		this.pst1 = this.connection.prepareStatement("insert into license_details values(?,?,?)");
				
	}
	
public boolean register(License_details  license_details) throws Exception {
		
		this.pst1.setString(1, license_details.getAppl_id());
		this.pst1.setString(2, license_details.getLearning_no());
		this.pst1.setString(3, license_details.getExpiray_date());
		
		int status = this.pst1.executeUpdate();
		
		if(status > 0)
			return true;
				
		return false;
		
}
	

public static LicenseDAO getInstance() throws Exception
{
	if(dao == null)
		dao = new LicenseDAOImpl();
	
	return dao;
}

	
}
