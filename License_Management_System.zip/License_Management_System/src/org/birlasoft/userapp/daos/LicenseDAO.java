package org.birlasoft.userapp.daos;

import org.birlasoft.userapp.pojo.License_details;

public interface LicenseDAO {
	
	public boolean register(License_details license_details) throws Exception;

}
