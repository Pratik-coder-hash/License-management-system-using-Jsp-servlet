package org.birlasoft.userapp.daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.birlasoft.userapp.pojo.Userinfo;
import org.birlasoft.userapp.utils.ConnectionUtils;


public  class UserDAOImpl implements UserDAO {
	

	private PreparedStatement pst1,pst2,pst3;
	private Connection connection;	
	
	private static UserDAO dao = null;
	
	public UserDAOImpl() throws Exception {
		
		this.connection = ConnectionUtils.getConnection();
		
		this.pst1 = this.connection.prepareStatement("select * from userinfo where username = ? and password = ?");
		this.pst2 = this.connection.prepareStatement("insert into userinfo values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		this.pst3 = this.connection.prepareStatement("update userinfo set password = ? where username = ?");		
	}
		
	
	@Override
	public Userinfo authenticate(String username, String password) throws Exception {		
		
		this.pst1.setString(1, username);
		this.pst1.setString(2, password);
		
		ResultSet res = this.pst1.executeQuery();
		
		if(res.next())
		{
			Userinfo u = new Userinfo(res.getString(1), res.getString(2), res.getString(3), res.getDate(4), res.getString(5), res.getString(6), res.getString(7), res.getString(8),res.getString(9), res.getString(10), res.getString(11), res.getString(12), res.getString(13), res.getString(14), res.getString(15), res.getString(16), res.getString(17) );
			return u;
		}		
		
		return null;
	}

	public boolean register(Userinfo userinfo) throws Exception {
		
		this.pst2.setString(1, userinfo.getFname());
		this.pst2.setString(2, userinfo.getMname());
		this.pst2.setString(3, userinfo.getLname());
		this.pst2.setDate(4, userinfo.getDOB());
		this.pst2.setString(5, userinfo.getGender());
		this.pst2.setString(6, userinfo.getAge());
		this.pst2.setString(7, userinfo.getAddress());
		this.pst2.setString(8, userinfo.getAadhar_card());
		this.pst2.setString(9, userinfo.getPan_card());
		this.pst2.setString(10, userinfo.getQualification());
		this.pst2.setString(11, userinfo.getPayment_type());
		this.pst2.setString(12, userinfo.getPhone_no());
		this.pst2.setString(13, userinfo.getCountry());
		this.pst2.setString(14, userinfo.getState());
		this.pst2.setString(15, userinfo.getCity());
		this.pst2.setString(16, userinfo.getUsername());
		this.pst2.setString(17, userinfo.getPassword());
		
		int status = this.pst2.executeUpdate();
		
		if(status > 0)
			return true;
				
		return false;
	}

	@Override
	public boolean changePassword(String Username
			, String newpassword) throws Exception {
		
		this.pst3.setString(1, newpassword);
		this.pst3.setString(2, Username);
		
		int status = this.pst3.executeUpdate();
		
		if(status > 0)
			return true;		
		
		return false;
	}
	
	public static UserDAO getInstance() throws Exception
	{
		if(dao == null)
			dao = new UserDAOImpl();
		
		return dao;
	}


	

}

	
	
	
	


