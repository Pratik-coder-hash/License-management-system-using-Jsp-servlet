package org.birlasoft.userapp.daos;

import org.birlasoft.userapp.pojo.Admininfo;

public interface AdminDAO {
	
    public Admininfo authenticate(String username,String password) throws Exception;
	
	
	
	public boolean changePassword(String username,String newpassword) throws Exception;

}
