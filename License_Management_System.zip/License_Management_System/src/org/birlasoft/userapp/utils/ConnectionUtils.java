package org.birlasoft.userapp.utils;


import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionUtils {
	

	static private Connection connection = null;
	
	public static Connection getConnection() throws Exception
	{
		if(connection == null)
		{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/userappdb?serverTimezone=UTC", "root", "");
		}		
		
		return connection;
	}

}
