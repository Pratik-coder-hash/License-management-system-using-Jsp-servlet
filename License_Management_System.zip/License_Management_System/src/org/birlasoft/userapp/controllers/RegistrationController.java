package org.birlasoft.userapp.controllers;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.birlasoft.userapp.daos.UserDAO;
import org.birlasoft.userapp.daos.UserDAOImpl;
import org.birlasoft.userapp.pojo.Userinfo;

/**
 * Servlet implementation class RegistrationController
 */
@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String fname = request.getParameter("fname");
			String mname = request.getParameter("mname");
			String lname = request.getParameter("lname");
			String age = request.getParameter("age");
			Date dob = Date.valueOf(request.getParameter("dob"));
			String qualification = request.getParameter("qualification");
			String phone = request.getParameter("phone");
			String aadhar_card = request.getParameter("aadhar");
			String pan_card = request.getParameter("pancard");
			String address = request.getParameter("address");
			String city = request.getParameter("city");
			String state = request.getParameter("state");
			String country = request.getParameter("country");
			String payment_type = request.getParameter("payment");
			String gender = request.getParameter("gender");
			
		//	Userinfo userinfo = new Userinfo(username, password, fname, mname, lname, age, dob, qualification, phone, aadhar_card, pan_card, address,  city, state, country, payment_type, gender);
			
			Userinfo userinfo = new Userinfo(fname, mname, lname, dob, gender, age, address, phone, aadhar_card, pan_card, qualification, country, state, city, payment_type, username, password);
			
			UserDAO dao = UserDAOImpl.getInstance();
			
			boolean status = dao.register(userinfo);
			
			HttpSession session = request.getSession();			
			
			if(status)
			{
				response.sendRedirect("./Pages/success.jsp");
			}
			else
			{
				session.setAttribute("regmessage", "Something went wrong, please try again");
				response.sendRedirect("./Pages/Register.jsp");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	
	}

}
