package org.birlasoft.userapp.controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.birlasoft.userapp.daos.AdminDAO;
import org.birlasoft.userapp.daos.AdminDAOImpl;
import org.birlasoft.userapp.pojo.Admininfo;

/**
 * Servlet implementation class ChangeAuthentication
 */
@WebServlet("/ChangeAuthentication")
public class ChangeAuthentication extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangeAuthentication() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		try
		{
			String Username = request.getParameter("username");
			String NewPassword = request.getParameter("newpassword");
		
			AdminDAO dao = AdminDAOImpl.getInstance();
		
			boolean status = dao.changePassword(Username, NewPassword);
		
			HttpSession session = request.getSession();			
			
			if(status)
			{
				session.setAttribute("message", "You have Succesfully Changed Your Password");
				response.sendRedirect("./Pages/index.jsp");
			}
			else
			{
				
				response.sendRedirect("./Pages/ChangeAd.jsp");
			}		
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
