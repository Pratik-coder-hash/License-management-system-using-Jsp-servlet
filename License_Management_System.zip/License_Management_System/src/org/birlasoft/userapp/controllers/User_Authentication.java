package org.birlasoft.userapp.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.birlasoft.userapp.daos.UserDAO;
import org.birlasoft.userapp.daos.UserDAOImpl;
import org.birlasoft.userapp.pojo.Userinfo;
/**
 * Servlet implementation class User_Authentication
 */
@WebServlet("/User_Authentication")
public class User_Authentication extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public User_Authentication() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try
		{
			String username = request.getParameter("username");
			String password = request.getParameter("password");
		
			UserDAO dao = UserDAOImpl.getInstance();
		
			Userinfo userinfo = dao.authenticate(username, password);
		
			HttpSession session = request.getSession();			
			
			if(userinfo == null)
			{
				session.setAttribute("message", "Invalid Username or password");
				response.sendRedirect("./Pages/User_login.jsp");
			}
			else
			{
				session.setAttribute("userinfo", userinfo);
				response.sendRedirect("./Pages/User_home.jsp");
			}		
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
