package org.birlasoft.userapp.controllers;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.birlasoft.userapp.daos.AdminDAO;
import org.birlasoft.userapp.daos.AdminDAOImpl;
import org.birlasoft.userapp.pojo.Admininfo;


/**
 * Servlet implementation class AuthenticationController
 */
@WebServlet("/AuthenticationController")
public class AuthenticationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AuthenticationController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		try
		{
			String Username = request.getParameter("username");
			String Password = request.getParameter("password");
		
			AdminDAO dao = AdminDAOImpl.getInstance();
		
			Admininfo admininfo = dao.authenticate(Username, Password);
		
			HttpSession session = request.getSession();			
			
			if(admininfo == null)
			{
				session.setAttribute("message", "Invalid Username or Password");
				response.sendRedirect("./Pages/index.jsp");
			}
			else
			{
				session.setAttribute("Admininfo", admininfo);
				response.sendRedirect("./Pages/Admin_Home.jsp");
			}		
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
