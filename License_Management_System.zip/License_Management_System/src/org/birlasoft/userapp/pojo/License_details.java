package org.birlasoft.userapp.pojo;

public class License_details {
	
	private String appl_id;
	private String learning_no;
	private String expiray_date;
	
	public License_details() {
		
	}

	
	public License_details(String appl_id, String learning_no, String expiray_date) {
		super();
		this.appl_id = appl_id;
		this.learning_no = learning_no;
		this.expiray_date = expiray_date;
	}


	public String getAppl_id() {
		return appl_id;
	}


	public void setAppl_id(String appl_id) {
		this.appl_id = appl_id;
	}


	public String getLearning_no() {
		return learning_no;
	}


	public void setLearning_no(String learning_no) {
		this.learning_no = learning_no;
	}


	public String getExpiray_date() {
		return expiray_date;
	}


	public void setExpiray_date(String expiray_date) {
		this.expiray_date = expiray_date;
	}
	
	
	
	
	
}




