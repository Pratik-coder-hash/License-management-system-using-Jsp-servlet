package org.birlasoft.userapp.pojo;

import java.sql.Date;

public class Userinfo {

	private String fname, mname, lname;
	private String username;
	private String password;
	private Date dob;
	private String gender;
	private String age;
	private String address;	
	private String phone_no;
	private String aadhar_card;
	private String pan_card;
	private String qualification;
	private String country;
	private String state;
	private String city;
	private String payment_type;
	
	
	public Userinfo() {
		// TODO Auto-generated constructor stub
	}

	public Userinfo(String fname, String mname, String lname, Date dob,
			String gender, String age, String address, String phone_no,
			String aadhar_card, String pan_card, String qualification, String country,
			String state, String city, String payment_type, String username, String password ) {
		super();
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.dob = dob;
		this.gender = gender;
		this.age = age;
		this.address = address;
		this.phone_no = phone_no;
		this.aadhar_card = aadhar_card;
		this.pan_card = pan_card;
		this.qualification = qualification;
		this.country = country;
		this.state = state;
		this.city = city;
		this.payment_type = payment_type;
		this.username = username;
		this.password = password;
	}

	

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		fname = fname;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		mname = mname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		lname = lname;
	}

	public Date getDOB() {
		return dob;
	}

	public void setDOB(Date dOB) {
		dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		gender = gender;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		address = address;
	}

	public String getPhone_no() {
		return phone_no;
	}

	public void setPhone_no(String phone_no) {
		phone_no = phone_no;
	}

	public String getAadhar_card() {
		return aadhar_card;
	}

	public void setAadhar_card(int aadhar_card) {
		aadhar_card = aadhar_card;
	}

	public String getPan_card() {
		return pan_card;
	}

	public void setPan_card(String pan_card) {
		this.pan_card = pan_card;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		qualification = qualification;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		city = city;
	}

	public String getPayment_type() {
		return payment_type;
	}

	public void setPayment_type(String payment_type) {
		payment_type = payment_type;
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		username = username;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		password = password;
	}

	
	

}
