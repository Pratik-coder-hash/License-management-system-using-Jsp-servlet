package org.birlasoft.userapp.pojo;

public class Admininfo {
	
	private String username;
	private String password;


public Admininfo(){
	
}


public Admininfo(String Username, String Password) {
	super();
	this.username = Username;
	this.password = Password;
}


public String getUsername() {
	return username;
}


public void setUsername(String Username) {
	username = Username;
}


public String getPassword() {
	return password;
}


public void setPassword(String Password) {
	Password = password;
}

}

